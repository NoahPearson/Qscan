#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 19 15:10:03 2023

@author: noah
"""

# FUNCTIONS FOR READING DATA, QSCAN, AND DENOISING

import numpy as np
import matplotlib.pyplot as plt

def read_data(ft_file_name,asd_file_name):
    """read in FT and ASD data from file"""
    # read in FT data
    freqs = np.loadtxt(ft_file_name)[:,0]
    res = np.loadtxt(ft_file_name)[:,1]
    ims = np.loadtxt(ft_file_name)[:,2]

    nn = freqs.shape[0]
    ft_data = np.zeros((nn,3))
    ft_data[:,0] = freqs # frequencies
    ft_data[:,1] = res # real parts
    ft_data[:,2] = ims # imaginary parts

    # read in Amplitude Spectral Density (ASD = sqrt(PSD))
    asd = np.loadtxt(asd_file_name)[:,1]
    asd_data = np.zeros((nn,2))
    asd_data[:,0] = freqs # frequencies (same as FT data)
    asd_data[:,1] = asd # ASDs
    
    return ft_data,asd_data

def read_plot_data(ft_file_name):
    """read in T,F,Amp data from file"""

    times = np.loadtxt(ft_file_name)[:,0]
    freqs = np.loadtxt(ft_file_name)[:,1]
    amps = np.loadtxt(ft_file_name)[:,2]

    nn = times.shape[0]
    qscan_plot_data = np.zeros((nn,3))
    qscan_plot_data[:,0] = times # frequencies
    qscan_plot_data[:,1] = freqs # real parts
    qscan_plot_data[:,2] = amps # imaginary parts
    
    return qscan_plot_data          

def read_corr(ft_file_name):
    """read in corr data from file"""
    corr = np.loadtxt(ft_file_name)
    return corr

def get_qscan(ft_data,asd_data,denoise_bool):
    """return the Qscan of the GW data (t,f,A), takes ft_data, asd_data"""
    
    df = abs(ft_data[0,0]-ft_data[1,0]) # frequency spacing
    Tobs = 1/df # observation period
    print("Observation time: ",Tobs)
    
    Nf = ft_data.shape[0] # number of frequencies or data points
    N = int(pow(2.0,np.ceil(np.log(Nf)/np.log(2.0)))) # round Nf to nearest power of 2 (for FFT)
    print("Number of frequency bins: ",N)
    
    NT = 2*N # number of time-domain bins
    
    data, freq = np.zeros(NT),np.zeros(NT)
    asd = np.zeros(N)
    Ns = N - Nf # number of data points to zero-pad
    
    data[0] = 0.0
    asd[0] = 1.0
    for i in range(1,Ns): # zero pad
        data[i] = 0.0 # real
        data[NT-i] = 0.0 # imaginary
        asd[i] = 1.0
        freq[i] = (i+1)/Tobs
    for i in range(Ns,N):
        freq[i] = ft_data[i-Ns,0]
        data[i] = ft_data[i-Ns,1] # real
        data[NT-i] = ft_data[i-Ns,2] # imaginary
        asd[i] = asd_data[i-Ns,1]
    
    # whiten the data by dividing the re/im parts by the asd
    print("Whitening data")
    for i in range(1,N):
        data[i] /= asd[i]
        data[NT-i] /= asd[i]
        
    # calculate Qscan
    Q,fmin,fmax = 8.0,ft_data[0,0],ft_data[-1,0] 
    qscan_data,Nf = qscanf(data,Q,Tobs,fmin,fmax,NT,denoise_bool)
    
    return qscan_data,NT,Nf

def qscanf(data,Q,Tobs,fmin,fmax,NT,denoise_bool):
    """calculate Qscan using frequency domain data"""
    
    dt = Tobs/NT # time-domain spacing
    
    #log frequency scale
    subscale = 40 # number of semi-tones per octave
    octaves = round(np.log(fmax/fmin)/np.log(2.0)) # number of octaves
    Nf = subscale*octaves+1
    freqs = np.zeros(Nf) # frequencies used in the analysis
    dx = np.log(2.0)/subscale
    dlnf = dx
    x = np.log(fmin)
    for i in range(Nf):
        freqs[i] = np.exp(x)
        x += dx

    print(str(Nf) + " freqs " + str(NT) + " times")

    # wavelet transform
    tfDR,tfDI,tfD = get_wavelet_transform(data,freqs,Q,Tobs,NT,Nf)
    
    # denoise?
    if denoise_bool:
        denoise(freqs, tfD, tfDR, Tobs,  NT, Nf)
 
    N = Nf*NT
    qscan_data = np.zeros((N,3))

    # arranging qscan data into matrix form amenable to plotting
    k,l = 0,0
    for j in range(Nf):
        f = freqs[j]
        for i in range(NT):
            t = i*dt
            shift = j*NT
            qscan_data[i+shift,0] = t 
            qscan_data[i+shift,1] = f 
            qscan_data[i+shift,2] = tfD[j][i] 
            x += tfD[j][i]
            k+=1
            if(tfD[j][i] > 9.0):
                l+=1
    
    return qscan_data,Nf

def get_wavelet_transform(data,freqs,Q,Tobs,NT,Nf):
    """get MG wavelet transform"""
    # arrays to hold the Qscan data
    tfDR = np.zeros((Nf,NT)) # real (cosine)
    tfDI = np.zeros((Nf,NT)) # imaginary (sine)
    tfD = np.zeros((Nf,NT)) # power
    
    fix = NT*NT/Tobs
    
    for j in range(Nf):
        b = SineGaussianC(freqs[j], Q, Tobs, NT) # b GOOD
        bmag = np.sqrt(f_nwip(b, b, NT)/fix) # bmag GOOD
        AC,AF = phase_blind_time_shift(data, b, NT)
        for i in range(NT):
            tfDR[j][i] = AC[i]/bmag # real inner product
            tfDI[j][i] = AF[i]/bmag # imaginary inner product
            tfD[j][i] = (tfDR[j][i]*tfDR[j][i]+tfDI[j][i]*tfDI[j][i]) # spectrogram

    return tfDR,tfDI,tfD

def SineGaussianC(freq,Q,Tobs,n):
    """compute wavelet appoximation"""
    # central time/phase set to zero
    # overall amplitude is irrelevant since the wavelets are normalized
    hs = np.zeros(n)
    f0,NMAX = freq,n
    tau = Q/(2.0*np.pi*f0)
    fmax = f0 + 4.0/tau # no point evaluating waveform past this freq (many efolds down)
    fmin = f0 - 4.0/tau # no point evaluating waveform before this freq (many efolds down)
    
    # set up region of wavelet support
    i = int(f0*Tobs);
    imin = int(fmin*Tobs);
    imax = int(fmax*Tobs);
    if imax - imin < 10:
        imin = i-5
        imax = i+5
    if imin < 0:
        imin = 0
    if imax > NMAX/2:
        imax = NMAX/2
    
    hs[0] = 0.0
    hs[NMAX//2] = 0.0
    
    for i in range(1,NMAX//2):
        hs[i] = 0.0
        hs[NMAX-i] = 0.0
        if i > imin and i < imax:
            f = i/Tobs
            sf = np.exp(-np.pi*np.pi*tau*tau*(f-f0)*(f-f0))
            hs[i] = sf
            hs[NMAX-i] = 0.0
    
    return hs

def f_nwip(a, b, n):
    """return wavelet normalization"""
    arg = 0.0
    for i in range(1,n//2):
        j = i
        k = n-j
        ReA = a[j]
        ImA = a[k]
        ReB = b[j]
        ImB = b[k]
        product = ReA*ReB + ImA*ImB
        arg += product
        
    return arg

def phase_blind_time_shift(a, b, n):
    """compute non-normalized inner products"""
    data1,data2 = a,b # data1 is the FT'd whitened data, data2 is the wavelet
    nb2 = n // 2
    corr,corrf = np.zeros(n),np.zeros(n)
    corr[0] = 0.0
    corrf[0] = 0.0
    corr[nb2] = 0.0
    corrf[nb2] = 0.0
    
    for i in range(1,nb2):
        l=i
        k=n-i
        corr[l] = (data1[l]*data2[l] + data1[k]*data2[k])
        corr[k] = (data1[k]*data2[l] - data1[l]*data2[k])
        corrf[l] = corr[k]
        corrf[k] = -corr[l]
    
    # rearranging data to complex form for ifft
    corr2 = np.zeros(nb2+1,dtype=np.complex_)
    corrf2 = np.zeros(nb2+1,dtype=np.complex_)

    for i in range(1,nb2):
        re = corr[i]
        im = corr[n-i]
        ref = corrf[i]
        imf = corrf[n-i]
        corr2[i] = complex(re,im)
        corrf2[i] = complex(ref,imf)
        
    corr2[nb2-1] = complex(corr[nb2],0)
    corrf2[nb2-1] = complex(corrf[nb2],0)
    corr2[0] = complex(0,0)
    corrf2[0] = complex(0,0)
    
    corr2_ifft = np.fft.irfft(corr2)
    corrf2_ifft = np.fft.irfft(corrf2)
    
    AC = corr2_ifft
    AF = corrf2_ifft
    
    return AC,AF

def denoise(freqs, tfD, tfDR, Tobs,  NT, Nf):
    """denoise the data - i.e. extract nongaussian features"""
    
    live = np.zeros((Nf,NT),dtype=(np.int32)) # indicator "map" of pixels above hot threshold
    live2 = np.zeros((Nf,NT),dtype=(np.int32)) # indicator "map" of pixels above warm threshold
    cluster = np.zeros((Nf,NT),dtype=(np.int32)) # cluster labeling
    
    dt = Tobs/NT # time spacing
    
    sthresh = 12.0
    warm = 9.0
    SNRcut = 4.0
    ttD = np.zeros((Nf,NT)) # used to reconstruct time domain signal
    
    for j in range(Nf):
        sqf = dt*np.sqrt(freqs[j]) # scaling used to convert to time domain
        for i in range(NT):
            ttD[j,i] = sqf*tfDR[j,i]

    k = 0 # counter for number of "hot" pixels above threshold
    # applying threshhold
    for j in range(Nf):
        for i in range(NT):
            live[j,i] = -1
            if tfD[j,i] > sthresh:
                live[j,i] = 1
                k+=1
            live2[j,i] = live[j,i]
    
    print("initial hot pixels = ",k)
    
    # dig deeper to extract clustered power
    
    for j in range(1,Nf-1):
        for i in range(1,NT-1):
            flag = 0
            for jj in range(-1,1):
                for ii in range(-1,1):
                    if live[j+jj,i+ii] == 1:
                        flag = 1 # highlight warm pixels in unit neighborhood
            if flag == 1 and tfD[j,i] > warm:
                live2[j,i] = 1 # if neighboring warm pixels are above warm threshold, include them
                
    k = 0 # counter for number of "warm" pixels above threshold
    for j in range(Nf):
        for i in range(NT):
            if live2[j,i] == 1:
                k+=1
                
    print("hot pixels = ",k)
    
    # identify initial clusters
    p = 0
    for j in range(1,Nf-1):
        for i in range(1,NT-1):
            if live2[j,i] > 0 and cluster[j,i] == 0: # start building clusters
                p+=1
                cluster[j,i] = p # numbering (label) the cluster
                for jj in range(-1,1): # looking at unit neighborhood pixels
                    for ii in range(-1,1):
                        if live2[j+jj,i+ii] > 0:
                            cluster[j+jj,i+ii] = p # assign neighboring warm pixels to same cluster
                
    ci = p
    print("initial clusters = ",ci)
    
    # paint clustering algorithm:
    num_sweeps = 10 # number of times to perform clustering
    for k in range(num_sweeps):
        for j in range(1,Nf-1):
            for i in range(1,NT-1):
                if cluster[j,i] > 0: # try to add to cluster
                    for jj in range(-1,1):
                        for ii in range(-1,1): # look at unit neighborhood
                            if live2[j+jj,i+ii] > 0:
                                cluster[j+jj,i+ii] = cluster[j,i]

    count = np.zeros(ci+1) 
    # counting number of pixels in each cluster?     
    for j in range(Nf):
            for i in range(NT):
                if cluster[j,i] > 0:
                    count[cluster[j,i]]+=1
                    
    k = 0
    for j in range(ci):
        if count[j] > 0:
            k+=1
    cf = k
    print("final clusters = ",cf)

    cSNRsq = np.zeros(cf)
    pix_list,num = np.zeros(cf),np.zeros(cf)
    rlist = np.zeros(ci) # maps final cluster to initial clusters
    
    k = 0
    for j in range(ci):
        if count[j] > 0:
            pix_list[k] = j
            rlist[j] = k
            num[k] = count[j]
            k+=1

    DT = np.zeros((cf,NT)) # TD signal for each cluster
    Dtotal = np.zeros(NT)

    for j in range(Nf):
        for i in range(NT):
            if cluster[j,i] > 0:
                jj = rlist[cluster[j,i]] # label of the final cluster
                DT[jj,i] += ttD[j,i]
                
    for j in range(cf):
        cSNRsq[j] = 0.0
        for i in range(NT):
            cSNRsq[j] += DT[j,i]**2
        cSNRsq[j] = np.sqrt(cSNRsq[j])
        print("SNR of cluster " + str(j) + " = ",cSNRsq[j])

    # build the excess power model
    k = 0
    for j in range(cf):
        if cSNRsq[j] > SNRcut:
            k+=1
            for i in range(NT):
                Dtotal[i] += DT[j,i]
    
    print("significant cluster(s) = ",k)
 
    # export glitch data
    
    glitch_data = np.zeros((NT,2))
    
    for i in range(NT):
        glitch_data[i,0] = i*dt
        glitch_data[i,1] = Dtotal[i]
          
    np.savetxt("me_wglitch.txt",glitch_data)
        
        
    # Compute the excess power (relative to the current spectral model
    S = 0.0
    for i in range(NT):
        S += Dtotal[i]**2

    S = np.sqrt(S)
    print("Excess SNR = ",S)



# PLOTTING

# TODO fix frequency scale
def plot_qscan(qscan_data,NT,Nf):
    """plot in t-f the qscan"""

    vmin,vmax = 0,12 # "saturation" bounds on pixel plots
    aspect = 'auto'
    t1,t2 = 0,qscan_data[-1,0] # start and end time labels
    f1,f2 = 20,qscan_data[-1,1] # start and end freq labels
    
    qscan_plotdata = np.zeros((NT,Nf))
    for f in range(Nf):
        for t in range(NT):
            qscan_plotdata[t,f] = qscan_data[t+f*NT,2]
    
    fig,ax = plt.subplots()
    im = plt.imshow(np.rot90(qscan_plotdata),cmap=plt.cm.YlOrRd, 
                      extent=[t1,t2,f1,f2], interpolation='none', 
                      vmin = vmin, vmax = vmax, aspect=aspect)

    plt.title("GW  Qscan", fontsize=14)
    plt.ylabel('Frequency (Hz)', fontsize=14)
    plt.xlabel('Time (s)', fontsize=14)
    #ax.set_yscale('log',base=2)
    plt.colorbar(im)
    plt.show()