#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 19 14:57:49 2023

@author: noah

script to do Qscan of GW data
"""

import functions as func

# read in data
print("Reading in data")
ft_file_name,asd_file_name = "H1f.txt","H1asd.txt" # fourier transform and ASD data file names
ft_data,asd_data = func.read_data(ft_file_name, asd_file_name) # read in data

# get Qscan
print("Getting Noisy Qscan")
denoise_bool = False # boolean for denoising
qscan_data,NT,Nf = func.get_qscan(ft_data,asd_data,denoise_bool) # do the Qscan

 # plot Qscan
print("Plotting Qscan")
func.plot_qscan3(qscan_data, NT, Nf) # plot Qscan in T-F grid